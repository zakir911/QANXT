# Bug report — Verification — run all

1681 tests ran: 1620 passed, 21 failed, 40 skipped. The failures come down to 16 bugs (21 failing tests).

| | |
|---|---|
| Project | Golden form lab |
| Application | Golden Form Lab — http://127.0.0.1:4370 |
| Browser | Chromium 141.0.7390.37 |
| Started | 2026-10-15 15:47:44 UTC |
| Duration | 16 min 47 s |
| Results | 1681 tests: 1620 passed, 21 failed, 40 skipped |
| Run ID | d490a8b3-f499-42ad-9e67-e1b63a86b0a2 |

## Results by testing type

| Testing type | Result | Tests | Passed | Failed | Not run | Bugs |
|---|---|---|---|---|---|---|
| API | Passed | 37 | 37 | 0 | 0 | 0 |
| Accessibility | Failed | 150 | 148 | 2 | 0 | 2 |
| Boundary values | Failed | 162 | 159 | 3 | 0 | 1 |
| Browser compatibility | Passed | 60 | 20 | 0 | 40 | 0 |
| Conditional and dynamic fields | Failed | 12 | 11 | 1 | 0 | 1 |
| Cross-field rules | Failed | 3 | 1 | 2 | 0 | 2 |
| Equivalence partitions | Passed | 79 | 79 | 0 | 0 | 0 |
| Error handling | Passed | 58 | 58 | 0 | 0 | 0 |
| Exploratory | Failed | 65 | 64 | 1 | 0 | 1 |
| Functional | Passed | 27 | 27 | 0 | 0 | 0 |
| Input handling | Failed | 356 | 354 | 2 | 0 | 1 |
| Multi-step forms | Failed | 4 | 3 | 1 | 0 | 1 |
| Negative | Failed | 136 | 135 | 1 | 0 | 1 |
| Performance | Failed | 62 | 61 | 1 | 0 | 1 |
| Recovery | Passed | 19 | 19 | 0 | 0 | 0 |
| Reliability and duplicates | Failed | 57 | 56 | 1 | 0 | 1 |
| Responsive | Failed | 123 | 119 | 4 | 0 | 2 |
| Security | Failed | 44 | 42 | 2 | 0 | 2 |
| Smoke | Passed | 41 | 41 | 0 | 0 | 0 |
| State transitions | Passed | 56 | 56 | 0 | 0 | 0 |
| Validation | Passed | 49 | 49 | 0 | 0 | 0 |
| Visual | Passed | 62 | 62 | 0 | 0 | 0 |
| Workflows | Passed | 19 | 19 | 0 | 0 | 0 |

| Bug | Severity | Testing type | Title | Tests |
|---|---|---|---|---|
| BUG-01 DEF-0005 | Critical | Security | Make a payment: lacks an element it should have | 1 |
| BUG-02 DEF-0007 | Critical | Security | Search: writes input from q back into the page as markup | 1 |
| BUG-03 DEF-0008 | Major | Boundary values | Validation rules: accepts an invalid age (below its minimum) | 3 |
| BUG-04 DEF-0016 | Major | Input handling | Contact support: POST /error-handling fails with HTTP 500 | 2 |
| BUG-05 DEF-0010 | Major | Responsive | Delivery address: overflows a small screen | 2 |
| BUG-06 DEF-0015 | Major | Responsive | Page /address: overflows a small screen | 2 |
| BUG-07 DEF-0001 | Major | Cross-field rules | Book leave: accepts an invalid endDate (a cross-field rule) | 1 |
| BUG-08 DEF-0006 | Major | Cross-field rules | Create an account: accepts an invalid confirmPassword (a cross-field rule) | 1 |
| BUG-09 DEF-0011 | Major | Negative | Edit profile: accepts an invalid displayName (whitespace only) | 1 |
| BUG-10 DEF-0009 | Major | Accessibility | Feedback: does not tie the error to nickname | 1 |
| BUG-11 DEF-0004 | Major | Multi-step forms | Loan application: loses the value of a field | 1 |
| BUG-12 DEF-0003 | Major | Conditional and dynamic fields | Open an account: accepts an invalid companyName (a conditional requirement) | 1 |
| BUG-13 DEF-0014 | Major | Accessibility | Page /accessibility: breaks the accessibility rule color-contrast | 1 |
| BUG-14 DEF-0013 | Major | Performance | Quote request: responds more slowly than its budget | 1 |
| BUG-15 DEF-0012 | Major | Exploratory | Session note: POST /session-expiry fails with HTTP 500 | 1 |
| BUG-16 DEF-0002 | Major | Reliability and duplicates | Transfer money: sends a submission more than once | 1 |

## BUG-01: Make a payment: lacks an element it should have

**Testing type:** Security · **Severity:** Critical · **Priority:** High · **Defect:** DEF-0005 (Proposed)

Found by TC-1027 (Make a payment: carries an anti-forgery token), which fails at step 2: Confirm an anti-forgery token is present.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/payment |
| Form | Make a payment |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:51:05 UTC |

### Steps to reproduce

1. Open Make a payment — http://127.0.0.1:4370/payment
2. **Check:** Confirm an anti-forgery token is present **← fails here**
   > Expected the element to exist on the page, but it does not.

### Expected

A hidden anti-forgery field is present in the form.

### Actual

Expected the element to exist on the page, but it does not.

### Where to look

The form carries no anti-forgery token. Add a per-session token as a hidden field and verify it on the server (CWE-352). (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 2 failed](evidence/BUG-01/step-2-failure.png)

### Affected tests (1)

- **TC-1027** Make a payment: carries an anti-forgery token: Expected the element to exist on the page, but it does not.

### More evidence

- [execution.webm](evidence/BUG-01/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-01/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-2-failure.html](evidence/BUG-01/step-2-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-2-failure.a11y.json](evidence/BUG-01/step-2-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1027 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-02: Search: writes input from q back into the page as markup

**Testing type:** Security · **Severity:** Critical · **Priority:** High · **Defect:** DEF-0007 (Proposed)

Found by TC-1251 (Search: does not reflect markup typed into Search for), which fails at step 5: Confirm the input was not written back as markup.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/search |
| Form | Search |
| Field | q |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:51:22 UTC |

### Steps to reproduce

1. Open Search — http://127.0.0.1:4370/search
2. Enter a 45-character value in Search for
3. Choose "All" in Category
4. Press "Search"
5. **Check:** Confirm the input was not written back as markup **← fails here**
   > Input was written back into the page as live markup: 1 <qanxt-probe-cb7c6358> element(s) exist. The application does not encode what it reflects.
6. **Check:** Confirm the application handled it without a server error or leaked detail _(not reached)_

### Test data

| Field | Value |
|---|---|
| `q` | `<qanxt-probe-cb7c6358></qanxt-probe-cb7c6358>` |
| `category` | `All` |

### Expected

The marker element does not exist in the resulting page.

### Actual

Input was written back into the page as live markup: 1 <qanxt-probe-cb7c6358> element(s) exist. The application does not encode what it reflects.

### Where to look

Input from "q" is written into the page as live HTML (reflected cross-site scripting, CWE-79). Encode output in the template, or set textContent rather than innerHTML. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 5 failed](evidence/BUG-02/step-5-failure.png)

### API exchange

**GET http://127.0.0.1:4370/search/results?q=%3Cqanxt-probe-cb7c6358%3E%3C%2Fqanxt-probe-cb7c6358%3E&category=All** → 200  (152 ms)

### Replay without a browser

```sh
curl -i -X GET 'http://127.0.0.1:4370/search/results?q=%3Cqanxt-probe-cb7c6358%3E%3C%2Fqanxt-probe-cb7c6358%3E&category=All'
```

### Affected tests (1)

- **TC-1251** Search: does not reflect markup typed into Search for: Input was written back into the page as live markup: 1 <qanxt-probe-cb7c6358> element(s) exist. The application does not encode what it reflects.

### More evidence

- [execution.webm](evidence/BUG-02/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-02/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-02/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-02/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1251 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-03: Validation rules: accepts an invalid age (below its minimum)

**Testing type:** Boundary values · **Severity:** Major · **Priority:** High · **Defect:** DEF-0008 (Proposed)

Found by TC-1461 (Validation rules: refuses 17 (one step below the minimum of 18) in Age), which fails at step 9: Confirm 17 (one step below the minimum of 18) was refused. 3 tests in this run fail the same way (TC-1461, TC-1464, TC-1465).

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/validation |
| Form | Validation rules |
| Field | age |
| Endpoint | POST /validation |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:52:02 UTC |

### Steps to reproduce

1. Open Validation rules — http://127.0.0.1:4370/validation
2. Enter "abc" in Username
3. Enter "17" in Age
4. Enter "5000.00" in Amount
5. Enter "50" in Quantity
6. Enter "https://example.test/qa" in Website
7. Enter "0120120" in Phone
8. Press "Validate"
9. **Check:** Confirm 17 (one step below the minimum of 18) was refused **← fails here**
   > Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference VAL-0122." (now at http://127.0.0.1:4370/validation/done?ref=VAL-0122).

### Test data

| Field | Value |
|---|---|
| `age` | `17` |
| `phone` | `0120120` |
| `amount` | `5000.00` |
| `website` | `https://example.test/qa` |
| `quantity` | `50` |
| `username` | `abc` |

### Expected

The form is not accepted and Age is reported as invalid.

### Actual

Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference VAL-0122." (now at http://127.0.0.1:4370/validation/done?ref=VAL-0122).

### Where to look

The application accepted a value it should refuse for "age" (technique: min-1). The page declares the rule, so the browser would stop a normal user — but the server does not enforce it, and anything that skips the page's checks gets through. Add the same validation to the server-side handler and return an error tied to "age". (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 9 failed](evidence/BUG-03/step-9-failure.png)
![TC-1464: The page when step 9 failed](evidence/BUG-03/TC-1464-step-9-failure.png)
![TC-1465: The page when step 9 failed](evidence/BUG-03/TC-1465-step-9-failure.png)

### API exchange

**POST http://127.0.0.1:4370/validation** → 303  (14 ms)

Request:
```
_csrf=***REDACTED***&username=abc&age=17&amount=5000.00&quantity=50&website=https%3A%2F%2Fexample.test%2Fqa&phone=0120120
```

**GET http://127.0.0.1:4370/validation/done?ref=VAL-0122** → 200  (8 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/validation' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&username=abc&age=17&amount=5000.00&quantity=50&website=https%3A%2F%2Fexample.test%2Fqa&phone=0120120'
```

### Affected tests (3)

- **TC-1461** Validation rules: refuses 17 (one step below the minimum of 18) in Age: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference VAL-0122." (now at http://127.0.0.1:4370/validation/done?ref=VAL-0122).
- **TC-1464** Validation rules: refuses zero in Age: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference VAL-0123." (now at http://127.0.0.1:4370/validation/done?ref=VAL-0123).
- **TC-1465** Validation rules: refuses a negative value in Age: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference VAL-0124." (now at http://127.0.0.1:4370/validation/done?ref=VAL-0124).

### More evidence

- [execution.webm](evidence/BUG-03/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-03/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-9-failure.html](evidence/BUG-03/step-9-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-9-failure.a11y.json](evidence/BUG-03/step-9-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1461, TC-1464, TC-1465 in QA NXT — open this run and choose Run failed, or run the tests on their own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-04: Contact support: POST /error-handling fails with HTTP 500

**Testing type:** Input handling · **Severity:** Major · **Priority:** Low · **Defect:** DEF-0016 (Proposed)

Found by TC-0734 (Contact support: handles the word null in Message), which fails at step 5: Confirm the application handled it without a server error or leaked detail. 2 tests in this run fail the same way (TC-0734, TC-0737).

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/error-handling |
| Form | Contact support |
| Field | message |
| Endpoint | POST /error-handling |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 16:01:37 UTC |

### Steps to reproduce

1. Open Contact support — http://127.0.0.1:4370/error-handling
2. Enter "QA NXT test" in Subject
3. Enter "null" in Message
4. Press "Send"
5. **Check:** Confirm the application handled it without a server error or leaked detail **← fails here**
   > Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/error-handling → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### Test data

| Field | Value |
|---|---|
| `message` | `null` |
| `subject` | `QA NXT test` |

### Expected

The application accepts or refuses the value cleanly. A server error, an uncaught script error or internal detail on the page is a failure.

### Actual

Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/error-handling → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### Where to look

The server failed: POST /error-handling returned HTTP 500. Start in the server handler for that route. The request that triggered it, with the values sent, is under API exchange, and the curl command replays it without a browser. The page also showed internal error detail to the user — catch the error and show a generic message as well as fixing the cause. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### What the page showed

```
500 Internal Server Error
TypeError: Cannot read properties of null (reading 'trim')
at sendSupportMessage (/srv/form-lab/handlers.js:42:17)
at processTicksAndRejections (node:internal/process/task_queues:95:5)
```

### Screenshots

![The page when step 5 failed](evidence/BUG-04/step-5-failure.png)

### API exchange

**POST http://127.0.0.1:4370/error-handling** → 500  (17 ms)

Request:
```
_csrf=***REDACTED***&subject=QA+NXT+test&message=null
```

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/error-handling' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&subject=QA+NXT+test&message=null'
```

### Browser console

```
[error] Failed to load resource: the server responded with a status of 500 (Internal Server Error)
```

### Affected tests (2)

- **TC-0734** Contact support: handles the word null in Message: Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/error-handling → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.
- **TC-0737** Contact support: handles 5000 characters in Message: Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/error-handling → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### More evidence

- [execution.webm](evidence/BUG-04/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-04/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-04/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-04/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0734, TC-0737 in QA NXT — open this run and choose Run failed, or run the tests on their own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-05: Delivery address: overflows a small screen

**Testing type:** Responsive · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0010 (Proposed)

Found by TC-0175 (Delivery address: fits a tablet screen (768x1024)), which fails at step 3: Confirm nothing scrolls sideways. 2 tests in this run fail the same way (TC-0175, TC-0176).

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/address |
| Form | Delivery address |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 768x1024 |
| First seen | 2026-10-15 15:53:01 UTC |

### Steps to reproduce

1. Use a tablet screen (768x1024)
2. Open Delivery address — http://127.0.0.1:4370/address
3. **Check:** Confirm nothing scrolls sideways **← fails here**
   > The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.
4. **Check:** Confirm Address line 1 is shown _(not reached)_
5. **Check:** Confirm Address line 2 is shown _(not reached)_
6. **Check:** Confirm Town or city is shown _(not reached)_
7. **Check:** Confirm Postcode is shown _(not reached)_
8. **Check:** Confirm Country is shown _(not reached)_
9. **Check:** Confirm "Save address" is shown _(not reached)_

### Expected

Nothing overflows and every field is shown.

### Actual

The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.

### Where to look

An element is wider than the viewport. Look for fixed widths (width or min-width in px), and images or tables without max-width: 100%. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 3 failed](evidence/BUG-05/step-3-failure.png)
![TC-0176: The page when step 3 failed](evidence/BUG-05/TC-0176-step-3-failure.png)

### Affected tests (2)

- **TC-0175** Delivery address: fits a tablet screen (768x1024): The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.
- **TC-0176** Delivery address: fits a mobile screen (390x844): The page can be scrolled sideways by 532px in a 390px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.

### More evidence

- [execution.webm](evidence/BUG-05/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-05/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-3-failure.html](evidence/BUG-05/step-3-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-3-failure.a11y.json](evidence/BUG-05/step-3-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0175, TC-0176 in QA NXT — open this run and choose Run failed, or run the tests on their own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-06: Page /address: overflows a small screen

**Testing type:** Responsive · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0015 (Proposed)

Found by TC-1561 (Delivery address · QA NXT Golden Form Lab (/address): fits a tablet screen (768x1024)), which fails at step 3: Confirm nothing scrolls sideways. 2 tests in this run fail the same way (TC-1561, TC-1562).

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/address |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 768x1024 |
| First seen | 2026-10-15 15:58:12 UTC |

### Steps to reproduce

1. Use a tablet screen (768x1024)
2. Open Delivery address · QA NXT Golden Form Lab (/address) — http://127.0.0.1:4370/address
3. **Check:** Confirm nothing scrolls sideways **← fails here**
   > The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.

### Expected

Nothing on the page makes it scroll sideways.

### Actual

The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.

### Where to look

An element is wider than the viewport. Look for fixed widths (width or min-width in px), and images or tables without max-width: 100%. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 3 failed](evidence/BUG-06/step-3-failure.png)
![TC-1562: The page when step 3 failed](evidence/BUG-06/TC-1562-step-3-failure.png)

### Affected tests (2)

- **TC-1561** Delivery address · QA NXT Golden Form Lab (/address): fits a tablet screen (768x1024): The page can be scrolled sideways by 154px in a 768px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.
- **TC-1562** Delivery address · QA NXT Golden Form Lab (/address): fits a mobile screen (390x844): The page can be scrolled sideways by 532px in a 390px-wide window; the element reaching furthest is form#address, whose right edge is at 922px.

### More evidence

- [execution.webm](evidence/BUG-06/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-06/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-3-failure.html](evidence/BUG-06/step-3-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-3-failure.a11y.json](evidence/BUG-06/step-3-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1561, TC-1562 in QA NXT — open this run and choose Run failed, or run the tests on their own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-07: Book leave: accepts an invalid endDate (a cross-field rule)

**Testing type:** Cross-field rules · **Severity:** Major · **Priority:** High · **Defect:** DEF-0001 (Proposed)

Found by TC-0464 (Book leave: refuses Last day before First day), which fails at step 7: Confirm the reversed range was refused.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/date-form |
| Form | Book leave |
| Field | endDate |
| Endpoint | POST /date-form |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:49:13 UTC |

### Steps to reproduce

1. Open Book leave — http://127.0.0.1:4370/date-form
2. Enter "2025-07-01" in First day
3. Enter "2023-09-01" in Last day
4. Enter "09:30" in Start time
5. Enter "2026-06-15T09:30" in Remind me at
6. Press "Book"
7. **Check:** Confirm the reversed range was refused **← fails here**
   > Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DAT-0052." (now at http://127.0.0.1:4370/date-form/done?ref=DAT-0052).

### Test data

| Field | Value |
|---|---|
| `endDate` | `2023-09-01` |
| `reminder` | `2026-06-15T09:30` |
| `startDate` | `2025-07-01` |
| `startTime` | `09:30` |

### Expected

The form is not accepted and the order is reported.

### Actual

Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DAT-0052." (now at http://127.0.0.1:4370/date-form/done?ref=DAT-0052).

### Where to look

The application accepted a combination of values it should refuse. The rule between these fields is not enforced on the server: add the check to the submit handler and return an error attached to the second field. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 7 failed](evidence/BUG-07/step-7-failure.png)

### API exchange

**POST http://127.0.0.1:4370/date-form** → 303  (36 ms)

Request:
```
_csrf=***REDACTED***&startDate=2025-07-01&endDate=2023-09-01&startTime=09%3A30&reminder=2026-06-15T09%3A30
```

**GET http://127.0.0.1:4370/date-form/done?ref=DAT-0052** → 200  (2 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/date-form' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&startDate=2025-07-01&endDate=2023-09-01&startTime=09%3A30&reminder=2026-06-15T09%3A30'
```

### Affected tests (1)

- **TC-0464** Book leave: refuses Last day before First day: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DAT-0052." (now at http://127.0.0.1:4370/date-form/done?ref=DAT-0052).

### More evidence

- [execution.webm](evidence/BUG-07/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-07/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-7-failure.html](evidence/BUG-07/step-7-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-7-failure.a11y.json](evidence/BUG-07/step-7-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0464 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-08: Create an account: accepts an invalid confirmPassword (a cross-field rule)

**Testing type:** Cross-field rules · **Severity:** Major · **Priority:** High · **Defect:** DEF-0006 (Proposed)

Found by TC-1187 (Create an account: refuses Confirm password that does not match Password), which fails at step 8: Confirm the mismatch was refused.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/registration |
| Form | Create an account |
| Field | confirmPassword |
| Endpoint | POST /registration |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:51:16 UTC |

### Steps to reproduce

1. Open Create an account — http://127.0.0.1:4370/registration
2. Enter "QA NXT test" in Full name
3. Enter "qa.nxt@example.test" in Email address
4. Enter "QaNxt-Passw0rd!" in Password
5. Enter "Second-Passw0rd#" in Confirm password
6. Tick I accept the terms and conditions
7. Press "Create account"
8. **Check:** Confirm the mismatch was refused **← fails here**
   > Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference REG-0100." (now at http://127.0.0.1:4370/registration/done?ref=REG-0100).

### Test data

| Field | Value |
|---|---|
| `email` | `qa.nxt@example.test` |
| `terms` | `on` |
| `fullName` | `QA NXT test` |
| `password` | `QaNxt-Passw0rd!` |
| `confirmPassword` | `Second-Passw0rd#` |

### Expected

The form is not accepted and the mismatch is reported.

### Actual

Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference REG-0100." (now at http://127.0.0.1:4370/registration/done?ref=REG-0100).

### Where to look

The application accepted a combination of values it should refuse. The rule between these fields is not enforced on the server: add the check to the submit handler and return an error attached to the second field. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 8 failed](evidence/BUG-08/step-8-failure.png)

### API exchange

**POST http://127.0.0.1:4370/registration** → 303  (6 ms)

Request:
```
_csrf=***REDACTED***&fullName=QA+NXT+test&email=qa.nxt%40example.test&password=***REDACTED***&confirmPassword=Second-Passw0rd%23&terms=on
```

**GET http://127.0.0.1:4370/registration/done?ref=REG-0100** → 200  (46 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/registration' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&fullName=QA+NXT+test&email=qa.nxt%40example.test&password=***REDACTED***&confirmPassword=Second-Passw0rd%23&terms=on'
```

### Affected tests (1)

- **TC-1187** Create an account: refuses Confirm password that does not match Password: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference REG-0100." (now at http://127.0.0.1:4370/registration/done?ref=REG-0100).

### More evidence

- [execution.webm](evidence/BUG-08/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-08/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-8-failure.html](evidence/BUG-08/step-8-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-8-failure.a11y.json](evidence/BUG-08/step-8-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1187 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-09: Edit profile: accepts an invalid displayName (whitespace only)

**Testing type:** Negative · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0011 (Proposed)

Found by TC-1058 (Edit profile: refuses Display name containing only spaces), which fails at step 8: Confirm the whitespace-only value was refused.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/profile |
| Form | Edit profile |
| Field | displayName |
| Endpoint | POST /profile |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:56:18 UTC |

### Steps to reproduce

1. Open Edit profile — http://127.0.0.1:4370/profile
2. Enter 3 space(s) in Display name
3. Enter "qa.nxt@example.test" in Email
4. Enter "QA NXT test notes" in Bio
5. Enter "https://example.test/qa" in Website
6. Enter "0120120" in Phone
7. Press "Save profile"
8. **Check:** Confirm the whitespace-only value was refused **← fails here**
   > Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference PRO-0257." (now at http://127.0.0.1:4370/profile/done?ref=PRO-0257).

### Test data

| Field | Value |
|---|---|
| `bio` | `QA NXT test notes` |
| `email` | `qa.nxt@example.test` |
| `phone` | `0120120` |
| `website` | `https://example.test/qa` |
| `displayName` | `   ` |

### Expected

The form is not accepted; Display name is treated as empty.

### Actual

Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference PRO-0257." (now at http://127.0.0.1:4370/profile/done?ref=PRO-0257).

### Where to look

The application accepted a value it should refuse for "displayName" (technique: whitespace-only). The page declares the rule, so the browser would stop a normal user — but the server does not enforce it, and anything that skips the page's checks gets through. Add the same validation to the server-side handler and return an error tied to "displayName". (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 8 failed](evidence/BUG-09/step-8-failure.png)

### API exchange

**POST http://127.0.0.1:4370/profile** → 303  (8 ms)

Request:
```
_csrf=***REDACTED***&displayName=+++&email=qa.nxt%40example.test&bio=QA+NXT+test+notes&website=https%3A%2F%2Fexample.test%2Fqa&phone=0120120
```

**GET http://127.0.0.1:4370/profile/done?ref=PRO-0257** → 200  (7 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/profile' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&displayName=+++&email=qa.nxt%40example.test&bio=QA+NXT+test+notes&website=https%3A%2F%2Fexample.test%2Fqa&phone=0120120'
```

### Affected tests (1)

- **TC-1058** Edit profile: refuses Display name containing only spaces: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference PRO-0257." (now at http://127.0.0.1:4370/profile/done?ref=PRO-0257).

### More evidence

- [execution.webm](evidence/BUG-09/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-09/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-8-failure.html](evidence/BUG-09/step-8-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-8-failure.a11y.json](evidence/BUG-09/step-8-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1058 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-10: Feedback: does not tie the error to nickname

**Testing type:** Accessibility · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0009 (Proposed)

Found by TC-0041 (Feedback: announces the error for Nickname with the field), which fails at step 4: Confirm the error is tied to Nickname.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/accessibility |
| Form | Feedback |
| Field | nickname |
| Endpoint | POST /accessibility |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:52:50 UTC |

### Steps to reproduce

1. Open Feedback — http://127.0.0.1:4370/accessibility
2. Enter "qa.nxt@example.test" in Email
3. Press "Send feedback"
4. **Check:** Confirm the error is tied to Nickname **← fails here**
   > The field shows an error, but assistive technology would not announce it with the field: no aria-invalid, no error referenced by aria-describedby, message beside it: "Enter nickname.".

### Test data

| Field | Value |
|---|---|
| `email` | `qa.nxt@example.test` |

### Expected

Nickname has aria-invalid and an aria-describedby (or browser validation) message.

### Actual

The field shows an error, but assistive technology would not announce it with the field: no aria-invalid, no error referenced by aria-describedby, message beside it: "Enter nickname.".

### Where to look

The error for "nickname" is shown but not tied to the field: set aria-invalid="true" on it and reference the error's id from aria-describedby (WCAG 3.3.1, 4.1.2), so a screen reader announces it with the field. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 4 failed](evidence/BUG-10/step-4-failure.png)

### API exchange

**POST http://127.0.0.1:4370/accessibility** → 422  (49 ms)

Request:
```
_csrf=***REDACTED***&nickname=&email=qa.nxt%40example.test
```

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/accessibility' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&nickname=&email=qa.nxt%40example.test'
```

### Browser console

```
[error] Failed to load resource: the server responded with a status of 422 (Unprocessable Entity)
```

### Affected tests (1)

- **TC-0041** Feedback: announces the error for Nickname with the field: The field shows an error, but assistive technology would not announce it with the field: no aria-invalid, no error referenced by aria-describedby, message beside it: "Enter nickname.".

### More evidence

- [execution.webm](evidence/BUG-10/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-10/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-4-failure.html](evidence/BUG-10/step-4-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-4-failure.a11y.json](evidence/BUG-10/step-4-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0041 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-11: Loan application: loses the value of a field

**Testing type:** Multi-step forms · **Severity:** Major · **Priority:** High · **Defect:** DEF-0004 (Proposed)

Found by TC-0916 (Loan application: keeps the first step's answers after going back), which fails at step 6: Confirm Applicant name still holds what was entered.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/multi-step |
| Form | Loan application |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:50:38 UTC |

### Steps to reproduce

1. Open Loan application — http://127.0.0.1:4370/multi-step
2. Enter "QA NXT test" in Applicant name
3. Enter "qa.nxt@example.test" in Contact email
4. Press "Next"
5. Press "Previous"
6. **Check:** Confirm Applicant name still holds what was entered **← fails here**
   > Expected the value "QA NXT test" but found "" (waited 15193ms).
7. **Check:** Confirm Contact email still holds what was entered _(not reached)_

### Test data

| Field | Value |
|---|---|
| `email` | `qa.nxt@example.test` |
| `applicant` | `QA NXT test` |

### Expected

Every answer on the first step is still there.

### Actual

Expected the value "QA NXT test" but found "" (waited 15193ms).

### Where to look

The value of the field was lost. For a multi-step form, check that each step's answers are kept when the user goes back. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 6 failed](evidence/BUG-11/step-6-failure.png)

### Affected tests (1)

- **TC-0916** Loan application: keeps the first step's answers after going back: Expected the value "QA NXT test" but found "" (waited 15193ms).

### More evidence

- [execution.webm](evidence/BUG-11/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-11/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-6-failure.html](evidence/BUG-11/step-6-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-6-failure.a11y.json](evidence/BUG-11/step-6-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0916 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-12: Open an account: accepts an invalid companyName (a conditional requirement)

**Testing type:** Conditional and dynamic fields · **Severity:** Major · **Priority:** High · **Defect:** DEF-0003 (Proposed)

Found by TC-0660 (Open an account: requires Company name once it is shown), which fails at step 5: Confirm the empty Company name was refused.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/dynamic |
| Form | Open an account |
| Field | companyName |
| Endpoint | POST /dynamic |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:49:40 UTC |

### Steps to reproduce

1. Open Open an account — http://127.0.0.1:4370/dynamic
2. Choose "Business" in Account type
3. Enter "qa.nxt@example.test" in Email address
4. Press "Open account"
5. **Check:** Confirm the empty Company name was refused **← fails here**
   > Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DYN-0068." (now at http://127.0.0.1:4370/dynamic/done?ref=DYN-0068).

### Test data

| Field | Value |
|---|---|
| `email` | `qa.nxt@example.test` |
| `accountType` | `Business` |

### Expected

The form is not accepted while Company name is empty.

### Actual

Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DYN-0068." (now at http://127.0.0.1:4370/dynamic/done?ref=DYN-0068).

### Where to look

"companyName" is shown and required on the page once its trigger is answered, but the server accepts the submission without it. Enforce the same conditional requirement on the server. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 5 failed](evidence/BUG-12/step-5-failure.png)

### API exchange

**POST http://127.0.0.1:4370/dynamic** → 303  (18 ms)

Request:
```
_csrf=***REDACTED***&accountType=Business&companyName=&referralCode=&email=qa.nxt%40example.test
```

**GET http://127.0.0.1:4370/dynamic/done?ref=DYN-0068** → 200  (9 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/dynamic' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&accountType=Business&companyName=&referralCode=&email=qa.nxt%40example.test'
```

### Affected tests (1)

- **TC-0660** Open an account: requires Company name once it is shown: Expected the submission to be refused, but it was accepted: the form is gone; no field is marked invalid; no error message is shown; confirmation: "Thank you. We received it. Reference DYN-0068." (now at http://127.0.0.1:4370/dynamic/done?ref=DYN-0068).

### More evidence

- [execution.webm](evidence/BUG-12/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-12/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-12/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-12/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0660 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-13: Page /accessibility: breaks the accessibility rule color-contrast

**Testing type:** Accessibility · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0014 (Proposed)

Found by TC-1551 (Feedback · QA NXT Golden Form Lab (/accessibility): has no serious automated accessibility violations), which fails at step 2: Run the accessibility rules on the page.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/accessibility |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:58:10 UTC |

### Steps to reproduce

1. Open Feedback · QA NXT Golden Form Lab (/accessibility) — http://127.0.0.1:4370/accessibility
2. **Check:** Run the accessibility rules on the page **← fails here**
   > 1 violation(s) against wcag2a, wcag2aa, wcag21aa: 1 serious. 1 at serious or worse: color-contrast (serious) Elements must meet minimum color contrast ratio thresholds at p:nth-child(5) — https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=axeAPI.

### Expected

No serious or critical violation is reported for the page.

### Actual

1 violation(s) against wcag2a, wcag2aa, wcag21aa: 1 serious. 1 at serious or worse: color-contrast (serious) Elements must meet minimum color contrast ratio thresholds at p:nth-child(5) — https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=axeAPI.

### Where to look

Fix the accessibility rules listed below; each links to guidance on what the rule requires. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 2 failed](evidence/BUG-13/step-2-failure.png)

### Accessibility violations

- **color-contrast** (serious): Elements must meet minimum color contrast ratio thresholds https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=axeAPI — `p:nth-child(5)`

### Affected tests (1)

- **TC-1551** Feedback · QA NXT Golden Form Lab (/accessibility): has no serious automated accessibility violations: 1 violation(s) against wcag2a, wcag2aa, wcag21aa: 1 serious. 1 at serious or worse: color-contrast (serious) Elements must meet minimum color contrast ratio thresholds at p:nth-child(5) — https://dequeuniversity.com/rules/axe/4.13/color-contrast?application=axeAPI.

### More evidence

- [execution.webm](evidence/BUG-13/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-13/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-2-failure.html](evidence/BUG-13/step-2-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-2-failure.a11y.json](evidence/BUG-13/step-2-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1551 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-14: Quote request: responds more slowly than its budget

**Testing type:** Performance · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0013 (Proposed)

Found by TC-1424 (Quote request: answers a submission within 2000 ms), which fails at step 5: Confirm the response came within 2000 ms.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/slow-form |
| Form | Quote request |
| Endpoint | POST /slow-form |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:57:36 UTC |

### Steps to reproduce

1. Open Quote request — http://127.0.0.1:4370/slow-form
2. Enter "QA NXT test" in Company
3. Enter "250" in Seats
4. Press "Get a quote"
5. **Check:** Confirm the response came within 2000 ms **← fails here**
   > expected a response within 2000 ms but POST http://127.0.0.1:4370/slow-form took 3706 ms.

### Test data

| Field | Value |
|---|---|
| `seats` | `250` |
| `company` | `QA NXT test` |

### Expected

The submission is answered in under 2000 ms.

### Actual

expected a response within 2000 ms but POST http://127.0.0.1:4370/slow-form took 3706 ms.

### Where to look

The response took longer than its budget. The timing of each request is under API exchange; profile the server handler for the slowest one. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 5 failed](evidence/BUG-14/step-5-failure.png)

### API exchange

**POST http://127.0.0.1:4370/slow-form** → 303  (3706 ms)

Request:
```
_csrf=***REDACTED***&company=QA+NXT+test&seats=250
```

**GET http://127.0.0.1:4370/slow-form/done?ref=SLO-0304** → 200  (7 ms)

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/slow-form' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&company=QA+NXT+test&seats=250'
```

### Affected tests (1)

- **TC-1424** Quote request: answers a submission within 2000 ms: expected a response within 2000 ms but POST http://127.0.0.1:4370/slow-form took 3706 ms.

### More evidence

- [execution.webm](evidence/BUG-14/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-14/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-14/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-14/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1424 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-15: Session note: POST /session-expiry fails with HTTP 500

**Testing type:** Exploratory · **Severity:** Major · **Priority:** Medium · **Defect:** DEF-0012 (Proposed)

Found by TC-1318 (Session note: copes with the session disappearing before submission), which fails at step 5: Confirm the application handled it without a server error or leaked detail.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/session-expiry |
| Form | Session note |
| Endpoint | POST /session-expiry |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:57:08 UTC |

### Steps to reproduce

1. Open Session note — http://127.0.0.1:4370/session-expiry
2. Enter "QA NXT test notes" in Note
3. Clear the session
4. Press "Save note"
5. **Check:** Confirm the application handled it without a server error or leaked detail **← fails here**
   > Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/session-expiry → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### Test data

| Field | Value |
|---|---|
| `note` | `QA NXT test notes` |

### Expected

No server error: the user is asked to sign in again, or the submission is handled.

### Actual

Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/session-expiry → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### Where to look

The server failed: POST /session-expiry returned HTTP 500. Start in the server handler for that route. The request that triggered it, with the values sent, is under API exchange, and the curl command replays it without a browser. The page also showed internal error detail to the user — catch the error and show a generic message as well as fixing the cause. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### What the page showed

```
500 Internal Server Error
TypeError: Cannot read properties of null (reading 'trim')
at saveNote (/srv/form-lab/handlers.js:42:17)
at processTicksAndRejections (node:internal/process/task_queues:95:5)
```

### Screenshots

![The page when step 5 failed](evidence/BUG-15/step-5-failure.png)

### API exchange

**POST http://127.0.0.1:4370/session-expiry** → 500  (11 ms)

Request:
```
_csrf=***REDACTED***&note=QA+NXT+test+notes
```

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/session-expiry' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-raw '_csrf=***REDACTED***&note=QA+NXT+test+notes'
```

### Browser console

```
[error] Failed to load resource: the server responded with a status of 500 (Internal Server Error)
```

### Affected tests (1)

- **TC-1318** Session note: copes with the session disappearing before submission: Expected the application to handle this without an error, but 1 request(s) failed on the server, first POST http://127.0.0.1:4370/session-expiry → HTTP 500; the page shows internal error detail matching /\bat [\w$.<>]+ \([^)]*:\d+:\d+\)/.

### More evidence

- [execution.webm](evidence/BUG-15/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-15/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-15/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-15/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-1318 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## BUG-16: Transfer money: sends a submission more than once

**Testing type:** Reliability and duplicates · **Severity:** Major · **Priority:** High · **Defect:** DEF-0002 (Proposed)

Found by TC-0577 (Transfer money: sends one submission when the submit control is pressed twice quickly), which fails at step 5: Confirm at most one POST was sent.

| | |
|---|---|
| Application | Golden Form Lab |
| Page | http://127.0.0.1:4370/duplicate-submit |
| Form | Transfer money |
| Endpoint | POST /api/transfers |
| Browser | Chromium 141.0.7390.37 |
| Viewport | 1440x900 (default) |
| First seen | 2026-10-15 15:49:30 UTC |

### Steps to reproduce

1. Open Transfer money — http://127.0.0.1:4370/duplicate-submit
2. Enter "QA NXT test" in Payee
3. Enter "500.50" in Amount
4. Press "Send money" repeatedly
5. **Check:** Confirm at most one POST was sent **← fails here**
   > expected at most 1 POST submission(s) the server did not refuse but saw 2.

### Test data

| Field | Value |
|---|---|
| `payee` | `QA NXT test` |
| `amount` | `500.50` |

### Expected

Exactly one submission reaches the server.

### Actual

expected at most 1 POST submission(s) the server did not refuse but saw 2.

### Where to look

The submission was sent more than once. Disable the submit control while the request is in flight, and make the endpoint idempotent (an idempotency key, or a unique constraint on the business key) so a repeat cannot create a second record. (A starting point drawn from what the test observed, not a diagnosis of the code.)

### Screenshots

![The page when step 5 failed](evidence/BUG-16/step-5-failure.png)

### API exchange

**POST http://127.0.0.1:4370/api/transfers** → 201  (677 ms)

Request:
```
{
  "payee": "QA NXT test",
  "amount": "500.50"
}
```

Response:
```
{
  "reference": "DUP-0061"
}
```

**POST http://127.0.0.1:4370/api/transfers** → 201  (738 ms)

Request:
```
{
  "payee": "QA NXT test",
  "amount": "500.50"
}
```

Response:
```
{
  "reference": "DUP-0062"
}
```

### Replay without a browser

```sh
curl -i -X POST 'http://127.0.0.1:4370/api/transfers' \
  -H 'Content-Type: application/json' \
  --data-raw '{"payee":"QA NXT test","amount":"500.50"}'
```

### Affected tests (1)

- **TC-0577** Transfer money: sends one submission when the submit control is pressed twice quickly: expected at most 1 POST submission(s) the server did not refuse but saw 2.

### More evidence

- [execution.webm](evidence/BUG-16/execution.webm) — Video of the whole test.
- [trace.zip](evidence/BUG-16/trace.zip) — Playwright trace: every action with a DOM snapshot, the network and the console. Open it with `npx playwright show-trace trace.zip` or at https://trace.playwright.dev.
- [step-5-failure.html](evidence/BUG-16/step-5-failure.html) — The page's HTML when the step failed, with secrets masked.
- [step-5-failure.a11y.json](evidence/BUG-16/step-5-failure.a11y.json) — The accessibility tree when the step failed — what a screen reader is given.

### Verify the fix

Re-run TC-0577 in QA NXT — open this run and choose Run failed, or run the test on its own. Each passes when the fix is in, and fails again with this report's symptom if it is not.

## Not run

- 20 × This compatibility test runs only in Webkit; this run uses Chromium
- 20 × This compatibility test runs only in Firefox; this run uses Chromium

_Generated by QA NXT on 2026-10-15 16:04:39 UTC. Secrets are masked in every request, response and log._
