QA NXT bug report — Verification — run all

bug-report.html   Open in any browser. Start here.
bug-report.md     The same report as Markdown, to paste into an issue tracker.
bug-report.json   The same report as data.
evidence/BUG-nn/  Screenshots, the Playwright trace, the video and page snapshots for each bug.

A Playwright trace replays the test step by step with the DOM, network and console at each step:
    npx playwright show-trace evidence/BUG-01/trace.zip
or drop the file on https://trace.playwright.dev (it is opened in your browser, not uploaded).

Secrets, tokens, card numbers and passwords are masked in every file.
Screenshots, videos, traces and page snapshots show the application as the test saw it. If it
displays personal or customer data, share this pack the way you would share that data.
